<template>
  <el-row>
    <el-col :span="18">
      <el-form :inline="true" :model="searchForm">
        <el-form-item>
          <el-select v-model="searchForm.user_group_id" placeholder="请选择所属用户组">
            <el-option label="顶级组" :value="0"></el-option>
            <el-option v-for="(item,index) in userGroups" :key="index" :label="item.name" :value="item.id" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-input v-model="searchForm.name" placeholder="用户组名称" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="handleSearch">查询</el-button>
        </el-form-item>
      </el-form>
    </el-col>
    <el-col :span="6">
      <el-button type="success" style="float:right" @click="openDialog"><i class="el-icon-plus" />新增记录</el-button>
    </el-col>
  </el-row>
</template>

<script type="text/ecmascript-6">
export default {
  props:['userGroups'],
  data() {
    return {
      searchForm: {}
    }
  },
  methods: {
    handleSearch() {
      this.$emit('handleSearch', this.searchForm)
    },
    openDialog() {
      this.$emit('openDialog')
    }
  }
}
</script>

<style scoped lang="stylus" rel="stylesheet/stylus">

</style>
