<template>
  <el-table row-key="id" :data="tableData" style="width: 100%" border :default-sort="{prop: 'date', order: 'descending'}">
    <el-table-column align="left" prop="name" label="名称" :formatter="formatter" />

    <el-table-column align="center" prop="maplevel" label="地图缩放比例" :formatter="formatter" sortable />
    <el-table-column align="center" prop="lng" label="经度" :formatter="formatter" sortable />
    <el-table-column align="center" prop="lat" label="纬度" :formatter="formatter" sortable />
    <el-table-column align="center" label="操作">
      <template slot-scope="scope">
        <el-button size="mini" @click="handleEdit(scope.row)">编辑</el-button>
        <el-button size="mini" type="danger" @click="handleDelete(scope.row)">删除</el-button>
      </template>
    </el-table-column>
  </el-table>
</template>

<script>
export default {
  props: {
    listObj: {
      type: Object,
      default: {}
    }
  },
  data() {
    return {

    }
  },
  computed: {
    tableData() {
      let result = []
      if (this.listObj.data) {
        result = this.listObj.data.data
      }

      return result
    }
  },
  methods: {
    formatter(row, column) {
      return row[column.property] ? row[column.property] : '--'
    },
    handleEdit(row) {
      this.$emit('handleEdit', row)
    },
    handleDelete(row) {
      this.$emit('handleDelete', row)
    }
  }
}
</script>
<style lang="stylus">

</style>
