<template>
  <el-form ref="ruleForm" :model="formData" :rules="rules" label-width="100px" class="demo-ruleForm">
    <el-row>
      <el-col :span="24">
        <el-form-item label="用户名" prop="name">
          <el-input v-model="formData.name" placeholder="请输入用户组名称" />
        </el-form-item>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="12">
        <el-form-item label="上位组">
          <el-select v-model="formData.user_group_id" placeholder="请选择所属用户组">
            <el-option label="顶级组" :value="0" />
            <el-option label="自贡用户组" :value="1" />
            <el-option label="通燕高速用户组" :value="2" />
          </el-select>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="地图缩放" prop="maplevel">
          <el-input v-model="formData.maplevel" placeholder="请输入地图缩放比例" />
        </el-form-item>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="12">
        <el-form-item label="经度" prop="lng">
          <el-input v-model="formData.lng" placeholder="请输入所在经度" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="纬度" prop="lat">
          <el-input v-model="formData.lat" placeholder="请输入所在纬度" />
        </el-form-item>
      </el-col>
    </el-row>
    <el-form-item label="备注说明" prop="descri">
      <el-input v-model="formData.descri" type="textarea" placeholder="请输入备注说明" />
    </el-form-item>
    <el-form-item>
      <el-button type="primary" @click="submitForm('ruleForm')">提交</el-button>
      <el-button @click="resetForm('ruleForm')">重置</el-button>
    </el-form-item>
  </el-form>
</template>

<script>
export default {
  props: ['formData'],
  data() {
    return {
      imageUrl: '',
      rules: {
        name: [
          { required: true, message: '请输入项目名称', trigger: 'blur' }
        ],
        phone: [
          { required: true, message: '请输入项目负责人电话', trigger: 'blur' }
        ],
        lng: [
          { required: true, message: '请输入项目经度信息', trigger: 'blur' }
        ],
        lat: [
          { required: true, message: '请输入项目纬度信息', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.$emit('handleSubmit', this.formData)
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    resetForm(formName) {
      this.$refs[formName].resetFields()
    }
  }
}
</script>
<style lang="stylus">

</style>
