<template>
  <div class="attrs-wrapper">
    <el-tabs v-model="activeName" type="border-card" @tab-click="handleClick">
      <el-tab-pane label="设备属性" name="first">
        <mainForm
          ref="child"
          :form-data="device"
          :projects="projects"
          :fields="fields"
          :products="products"
          :devices="devices"
          :projects-select="projectsSelect"
          @handleSubmit="handleSubmit"
        />
      </el-tab-pane>
      <el-tab-pane label="设备配置" name="second">
        <settings :device="device" />
      </el-tab-pane>
      <el-tab-pane label="网关配置" name="thire">
        <rtu :device="device" />
      </el-tab-pane>
      <el-tab-pane label="设备指令" name="fourth">
        <action :device="device" />
      </el-tab-pane>
      <el-tab-pane label="设备端口" name="fifth">
        <property :device="device" />
      </el-tab-pane>
      <el-tab-pane label="扫描序列" name="sixth">
        <poll :device="device" />
      </el-tab-pane>
      <el-tab-pane label="端口显示集" name="seventh">
        <portDisplay :device="device" />
      </el-tab-pane>
      <el-tab-pane label="指令显示集" name="eighth">
        <actionDisplay :device="device" />
      </el-tab-pane>
      <el-tab-pane label="属性转发集" name="ninth">
        <regMap :device="device" />
      </el-tab-pane>
      <el-tab-pane label="portArrays" name="tenth" v-if="showPortArray">
        <portArray :device="device" />
      </el-tab-pane>
      <el-tab-pane label="片区" name="eleventh" v-if="showCell">
        <cell :device="device" />
      </el-tab-pane>
    </el-tabs>
  </div>
</template>
<script>
import poll from './components/poll'
import rtu from './components/rtu'
import action from './components/action'
import property from './components/property'
import settings from './components/settings'
import mainForm from './components/main-form'
import portDisplay from './components/port-display'
import actionDisplay from './components/action-display'
import regMap from './components/reg-map'
import portArray from './components/port-array'
import cell from './components/cell'
import { getProductTypes, getMakers, getProducts, getProjects, getFields, getDevices, getProjectsSelect } from '@/api/basedata'
import { getOne, updateOne } from '@/api/device'
const PG = 4
const DG = 5
export default {
  components: {
    cell,
    portArray,
    regMap,
    portDisplay,
    actionDisplay,
    poll,
    rtu,
    action,
    property,
    settings,
    mainForm
  },
  data() {
    return {
      activeName: 'first',
      formLabelWidth: '120px',
      product_types: [],
      makers: [],
      projects: [],
      fields: [],
      products: [],
      devices: [],
      device: {},
      projectsSelect: []
    }
  },
  created() {
    this.getBaseData()
    const serialno = this.$route.query.serialno
    this.getOne(serialno)
  },
  computed:{
    showPortArray(){
      return this.device.product_type == PG || this.device.product_type == DG
    },
    showCell(){
      return this.device.product_type == PG || this.device.product_type == DG
    },
  },
  methods: {
    async getBaseData() {
      const product_types = await getProductTypes()
      const makers = await getMakers()
      const products = await getProducts()
      const projects = await getProjects()
      const fields = await getFields()
      const devices = await getDevices()
      const projectsSelect = await getProjectsSelect()
      this.projectsSelect = projectsSelect.data
      this.product_types = product_types.data
      this.makers = makers.data
      this.products = products.data
      this.projects = projects.data
      this.fields = fields.data
      this.devices = devices.data
    },
    async getOne(serialno) {
      const { data } = await getOne(serialno)
      if (!data.rtu) {
        data.rtu = {
          serialno: data.serialno,
          uart: 0,
          rtuid: 1,
          protocol: 'rtu_on_tcp',
          port: 502,
          ip: '127.0.0.1',
          interping: 10,
          sotimeout: 3000,
          rwtimeout: 2000
        }
      }
      this.device = data
    },
    handleClick(tab, event) {
      console.log(tab, event)
    },
    handleSubmit(model) {
      updateOne(model.serialno, model).then((res) => {
        if (res.errorCode === 0) {
          this.$message.success(res.msg)
        }
      })
    }
  }
}
</script>

<style scoped lang="stylus" rel="stylesheet/stylus">
  .attrs-wrapper
    padding 16px
</style>
