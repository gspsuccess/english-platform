<template>
  <div class="app-container">
    <main-header
      :projects="projects"
      :fields="fields"
      :products="products"
      @openDialog="openDialog"
      @handleSearch="handleSearch"
    />
    <el-row>
      <list
        :list-obj="listObj"
        @handleEdit="handleEdit"
        @handleDelete="handleDelete"
        @handleCrc="handleCrc"
        @handleSwitch="handleSwitch"
      />
      <page-container :list-obj="listObj" @changeCurrentPage="changeCurrentPage" />
    </el-row>
    <el-dialog title="新增设备" :visible.sync="dialogFormVisible">
      <main-form-amount
        ref="child"
        :projects="projects"
        :fields="fields"
        :products="products"
        :projects-select="projectsSelect"
        :form-data="formData"
        @handleSubmit="handleSubmit"
      />
    </el-dialog>
  </div>
</template>

<script>
import { getAll, addOne, deleteOne, getCrcResult, valid, addAll } from '@/api/device'
import { getProjects, getFields, getProducts, getDevices, getProjectsSelect } from '@/api/basedata'
import mainFormAmount from './components/main-form-amount'
import mainHeader from './components/main-header'
import list from './components/list'
import PageContainer from '@/components/PageContainer'

const formData = {
  product_id: '',
  project_id: '',
  field_id: '',
  scada_id: '',
  amount: 1
}
export default {
  components: {
    mainFormAmount,
    mainHeader,
    list,
    PageContainer
  },
  data() {
    return {
      dialogFormVisible: false,
      projects: [],
      fields: [],
      projectsSelect: [],
      products: [],
      devices: [],
      formData: formData,
      listObj: {},
      listQuery: {
        page: 1,
        limit: 10
      }
    }
  },
  created() {
    this.getList()
    this.getBaseData()
  },
  methods: {
    async getList() {
      this.listLoading = true
      const listObj = await getAll(this.listQuery)
      this.listObj = listObj
    },
    async getBaseData() {
      const projects = await getProjects()
      this.projects = projects.data
      const fields = await getFields()
      this.fields = fields.data
      const products = await getProducts()
      this.products = products.data
      const devices = await getDevices()
      this.devices = devices.data
      const projectsSelect = await getProjectsSelect()
      this.projectsSelect = projectsSelect.data
    },
    changeCurrentPage(page) {
      this.listQuery.page = page
      this.getList()
    },
    openDialog() {
      this.title = '新增记录'
      this.formData = formData
      this.dialogFormVisible = true
    },
    handleSearch(data) {
      this.listQuery = Object.assign(this.listQuery, data)
      this.getList()
    },
    handleSubmit(model) {
      console.log('add')
      console.log(model)
      addAll(model).then((res) => {
        if (res.errorCode === 0) {
          this.$message.success(res.msg)
          this.resetForm()
        }
      })
    },
    async handleCrc(row) {
      const data = await getCrcResult(row.serialno)
      if (data.errorCode === 0) {
        this.$alert(data.data, '该设备的DTU串如下', {
          confirmButtonText: '确定',
          callback: action => {

          }
        })
      }
    },
    async handleSwitch(row, index) {
      const operateRaw = +!row.status
      const operate = row.status === 0 ? '失效' : '生效'
      this.$confirm('确定要' + operate + '该设备吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        valid(row.serialno, { status: row.status }).then((res) => {
          if (res.errorCode === 0) {
            this.$message({
              type: 'success',
              message: '操作成功!'
            })
            this.listObj.data.data[index].status = row.status
          } else {
            this.$message({
              type: 'error',
              message: '操作失败!'
            })
            this.listObj.data.data[index].status = operateRaw
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '取消操作'
        })
        this.listObj.data.data[index].status = operateRaw
      })
    },
    handleEdit(row) {
      this.$router.push({ path: '/device/attrs', query: { serialno: row.serialno }})
    },
    handleDelete(row) {
      this.$confirm('此操作将永久删除该条记录, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteOne(row.serialno).then((res) => {
          if (res.errorCode === 0) {
            this.$message.success(res.msg)
            this.getList()
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    resetForm() {
      this.getList()
      this.dialogFormVisible = false
      this.formData = formData
      this.$refs.child.resetForm('ruleForm')
    }
  }
}
</script>

<style lang="stylus">

</style>
