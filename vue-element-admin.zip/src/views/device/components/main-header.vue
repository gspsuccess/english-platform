<template>
  <el-row>
    <el-col :span="20">
      <el-form :inline="true" :model="searchForm" class="demo-form-inline">
        <el-form-item>
          <el-select v-model="searchForm.project_id" placeholder="所属项目">
            <el-option
              v-for="item in projects"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-select v-model="searchForm.field_id" placeholder="所属地块">
            <el-option
              v-for="item in fields"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-select v-model="searchForm.product_id" placeholder="所属产品">
            <el-option
              v-for="item in products"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-input v-model="searchForm.name" placeholder="设备名称" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="handleSearch">查询</el-button>
        </el-form-item>
      </el-form>
    </el-col>
    <el-col :span="4">
      <el-button type="success" style="float:right" @click="openDialog"><i class="el-icon-plus" />新增记录</el-button>
    </el-col>
  </el-row>
</template>

<script type="text/ecmascript-6">
export default {
  props: ['projects', 'fields', 'products'],
  data() {
    return {
      searchForm: {}
    }
  },
  methods: {
    handleSearch() {
      this.$emit('handleSearch', this.searchForm)
    },
    openDialog() {
      this.$emit('openDialog')
    }
  }
}
</script>

<style scoped lang="stylus" rel="stylesheet/stylus">

</style>
