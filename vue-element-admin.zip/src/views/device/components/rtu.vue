<template>
  <el-form ref="ruleForm" :model="rtu" :device="device" label-width="100px">
    <el-row>
      <el-col :span="12">
        <el-form-item label="协议">
          <el-input v-model="rtu.protocol" autocomplete="off" placeholder="请输入通信协议" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="通信设定">
          <el-input v-model="rtu.uart" autocomplete="off" placeholder="请输入通信设定信息" />
        </el-form-item>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="12">
        <el-form-item label="IP">
          <el-input v-model="rtu.ip" autocomplete="off" placeholder="请输入IP" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="端口号">
          <el-input v-model="rtu.port" autocomplete="off" placeholder="请输入端口号" />
        </el-form-item>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="12">
        <el-form-item label="rtuid">
          <el-input v-model="rtu.rtuid" autocomplete="off" placeholder="请输入rtuid" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="监视时间">
          <el-input v-model="rtu.interping" autocomplete="off" placeholder="请输入监视时间间隔" />
        </el-form-item>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="12">
        <el-form-item label="接续超时">
          <el-input v-model="rtu.sotimeout" autocomplete="off" placeholder="请输入接续超时时间" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="读写超时">
          <el-input v-model="rtu.rwtimeout" autocomplete="off" placeholder="请输入读写超时时间" />
        </el-form-item>
      </el-col>
    </el-row>
    <el-form-item>
      <el-button type="primary" @click="handleSubmit">保存结果</el-button>
    </el-form-item>
  </el-form>
</template>

<script type="text/ecmascript-6">
import { updateRtu } from '@/api/device'
export default {
  props: ['device'],
  data() {
    return {

    }
  },
  computed: {
    rtu() {
      return this.device.rtu ? this.device.rtu : {}
    }
  },
  methods: {
    async handleSubmit() {
      await updateRtu(this.device.serialno, this.rtu)
      this.$message.success('更新成功')
    }
  }
}
</script>

<style scoped lang="stylus" rel="stylesheet/stylus">

</style>
