<template>
  <div>
    <el-row style="margin-bottom:12px">
      <el-button type="success" @click="handleAdd">新增记录</el-button>
      <el-button type="primary" style="margin-left:12px;" @click="handleSubmit">保存结果</el-button>
    </el-row>
    <el-row>
      <el-table :data="tableData" style="width: 100%" highlight-current-row border>
        <el-table-column label="name">
          <template scope="scope">
            <el-input v-model="scope.row.name" size="small" placeholder="名称" />
          </template>
        </el-table-column>
        <el-table-column label="action_type">
          <template scope="scope">
            <el-input v-model="scope.row.action_type" size="small" placeholder="命令类型" />
          </template>
        </el-table-column>
        <el-table-column label="action_arr">
          <template scope="scope">
            <el-input v-model="scope.row.action_arr" size="small" placeholder="命令组合" />
          </template>
        </el-table-column>
        <el-table-column label="state_arr">
          <template scope="scope">
            <el-input v-model="scope.row.state_arr" size="small" placeholder="状态组合" />
          </template>
        </el-table-column>
        <el-table-column label="iconfont">
          <template scope="scope">
            <el-input v-model="scope.row.iconfont" size="small" placeholder="图标" />
          </template>
        </el-table-column>
        <el-table-column label="idx">
          <template scope="scope">
            <el-input v-model="scope.row.idx" size="small" placeholder="排序" />
          </template>
        </el-table-column>
        <el-table-column label="ref">
          <template scope="scope">
            <el-input v-model="scope.row.ref" size="small" placeholder="容器" />
          </template>
        </el-table-column>
        <el-table-column label="prefix">
          <template scope="scope">
            <el-input v-model="scope.row.prefix" size="small" placeholder="前置连接参数" />
          </template>
        </el-table-column>
        <el-table-column label="mode">
          <template scope="scope">
            <el-input v-model="scope.row.mode" size="small" placeholder="计算方式" />
          </template>
        </el-table-column>
        <el-table-column label="show_state">
          <template scope="scope">
            <el-switch
              v-model="scope.row.show_state"
              :active-value="1"
              :inactive-value="0">
            </el-switch>
          </template>
        </el-table-column>
        <el-table-column label="操作">
          <template scope="scope">
            <!--<el-button size="small" @click="handleEdit(scope.$index, scope.row)">编辑</el-button>-->
            <el-button size="small" type="danger" @click="handleDelete(scope.$index, scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-row>
    <el-row v-if="total > pageSize" style="margin-top:12px">
      <el-pagination
        background
        layout="prev, pager, next"
        :page-size="pageSize"
        :current-page="currentPage"
        :total="total"
        @current-change="pageChange"
      />
    </el-row>
  </div>
</template>

<script type="text/ecmascript-6">
import { updateRtuActionDisplays } from '@/api/device'
export default {
  props: ['device'],
  data() {
    return {
      currentPage: 1,
      pageSize: 10
    }
  },
  computed: {
    tableData() {
      if (this.device.rtu_action_displays) {
        const offset = (this.currentPage - 1) * this.pageSize
        return this.device.rtu_action_displays.slice(offset, offset + this.pageSize)
      }
      return []
    },
    total() {
      if (this.device.rtu_action_displays) {
        return this.device.rtu_action_displays.length
      }
      return 0
    }
  },
  methods: {
    handleAdd() {
      this.device.rtu_action_displays.push({
        serialno: this.device.serialno,
        name: '',
        action_type: '',
        action_arr: '',
        state_arr: '',
        iconfont: '',
        idx: '',
        ref: '',
        prefix: '',
        mode: '',
        show_state:0
      })
    },
    handleDelete(index, row) {
      this.device.rtu_action_displays.splice(index, 1)
    },
    async handleSubmit() {
      await updateRtuActionDisplays(this.device.serialno, this.device.rtu_action_displays)
      this.$message.success('更新成功')
    },
    pageChange(current_page) {
      this.currentPage = current_page
    }
  }
}
</script>

<style scoped lang="stylus" rel="stylesheet/stylus">

</style>
