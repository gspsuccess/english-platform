<template>
  <div>
    <el-row style="margin-bottom:12px">
      <el-button type="success" @click="handleAdd">新增记录</el-button>
      <el-button type="primary" style="margin-left:12px;" @click="handleSubmit">保存结果</el-button>
    </el-row>
    <el-row>
      <el-table :data="tableData" style="width: 100%" highlight-current-row border>
        <el-table-column label="name">
          <template scope="scope">
            <el-input v-model="scope.row.name" size="small" placeholder="名称" />
          </template>
        </el-table-column>
        <el-table-column label="namekey">
          <template scope="scope">
            <el-input v-model="scope.row.namekey" size="small" placeholder="外部参考名" />
          </template>
        </el-table-column>
        <el-table-column label="unit">
          <template scope="scope">
            <el-input v-model="scope.row.unit" size="small" placeholder="单位" />
          </template>
        </el-table-column>
        <el-table-column label="iconfont">
          <template scope="scope">
            <el-input v-model="scope.row.iconfont" size="small" placeholder="图标" />
          </template>
        </el-table-column>
        <el-table-column label="identity">
          <template scope="scope">
            <el-input v-model="scope.row.identity" size="small" placeholder="特征" />
          </template>
        </el-table-column>
        <el-table-column label="datatype">
          <template scope="scope">
            <el-input v-model="scope.row.datatype" size="small" placeholder="数据类型" />
          </template>
        </el-table-column>
        <el-table-column label="bool_format_arr">
          <template scope="scope">
            <el-input v-model="scope.row.bool_format_arr" size="small" placeholder="布尔值格式化数组" />
          </template>
        </el-table-column>
        <el-table-column label="idx">
          <template scope="scope">
            <el-input v-model="scope.row.idx" size="small" placeholder="排序" />
          </template>
        </el-table-column>
        <el-table-column label="操作">
          <template scope="scope">
            <!--<el-button size="small" @click="handleEdit(scope.$index, scope.row)">编辑</el-button>-->
            <el-button size="small" type="danger" @click="handleDelete(scope.$index, scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-row>
    <el-row v-if="total > pageSize" style="margin-top:12px">
      <el-pagination
        background
        layout="prev, pager, next"
        :page-size="pageSize"
        :current-page="currentPage"
        :total="total"
        @current-change="pageChange"
      />
    </el-row>
  </div>
</template>

<script type="text/ecmascript-6">
import { updateRtuPortDisplays } from '@/api/device'
export default {
  props: ['device'],
  data() {
    return {
      currentPage: 1,
      pageSize: 10
    }
  },
  computed: {
    tableData() {
      if (this.device.rtu_port_displays) {
        const offset = (this.currentPage - 1) * this.pageSize
        return this.device.rtu_port_displays.slice(offset, offset + this.pageSize)
      }
      return []
    },
    total() {
      if (this.device.rtu_port_displays) {
        return this.device.rtu_port_displays.length
      }
      return 0
    }
  },
  methods: {
    handleAdd() {
      this.device.rtu_port_displays.push({
        serialno: this.device.serialno,
        name: '',
        namekey: '',
        unit: '',
        iconfont: '',
        identity: '',
        datatype: '',
        bool_format_arr: '',
        idx: ''
      })
    },
    handleDelete(index, row) {
      this.device.rtu_port_displays.splice(index, 1)
    },
    async handleSubmit() {
      await updateRtuPortDisplays(this.device.serialno, this.device.rtu_port_displays)
      this.$message.success('更新成功')
    },
    pageChange(current_page) {
      this.currentPage = current_page
    }
  }
}
</script>

<style scoped lang="stylus" rel="stylesheet/stylus">

</style>
