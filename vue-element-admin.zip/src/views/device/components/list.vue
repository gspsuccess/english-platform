<template>
  <el-table :data="tableData" stripe border style="width: 100%">
    <el-table-column sortable align="center" prop="serialno" label="设备编号" />
    <el-table-column align="center" prop="name" label="设备名称" :formatter="formatter" />
    <el-table-column sortable align="center" prop="product.name" label="产品类型">
      <template slot-scope="scope">
        {{ scope.row.product?scope.row.product.name:'--' }}
      </template>
    </el-table-column>
    <el-table-column sortable align="center" prop="project.name" label="所属项目">
      <template slot-scope="scope">
        {{ scope.row.project?scope.row.project.name:'--' }}
      </template>
    </el-table-column>
    <el-table-column sortable align="center" prop="field.name" label="所属地块">
      <template slot-scope="scope">
        {{ scope.row.field?scope.row.field.name:'--' }}
      </template>
    </el-table-column>
    <el-table-column sortable align="center" prop="device_serialno" label="父级设备">
      <template slot-scope="scope">
        {{ scope.row.pdevice?scope.row.pdevice.name:'--' }}
      </template>
    </el-table-column>
    <el-table-column sortable align="center" prop="status" label="状态">
      <template slot-scope="scope">
        <el-switch
          v-model="scope.row.status"
          active-color="#13ce66"
          inactive-color="#bababa"
          :active-value="1"
          :inactive-value="0"
          @change="handleSwitch(scope.row,scope.$index)"
        />
      </template>
    </el-table-column>
    <el-table-column sortable align="center" prop="created_at" label="创建时间" />
    <el-table-column label="操作" align="center" width="280">
      <template slot-scope="scope">
        <el-button size="mini" type="primary" @click="handleCrc(scope.row)">查看DTU串</el-button>
        <el-button size="mini" type="default" @click="handleEdit(scope.row)">编辑</el-button>
        <el-button size="mini" type="danger" @click="handleDelete(scope.row)">删除</el-button>
      </template>
    </el-table-column>
  </el-table>
</template>

<script>
export default {
  props: {
    listObj: {
      type: Object,
      default() {
        return {}
      }
    }
  },
  data() {
    return {

    }
  },
  computed: {
    tableData() {
      let result = []
      if (this.listObj.data) {
        result = this.listObj.data.data
      }

      return result
    }
  },
  methods: {
    formatter(row, column) {
      return row[column.property] ? row[column.property] : '--'
    },
    handleEdit(row) {
      this.$emit('handleEdit', row)
    },
    handleDelete(row) {
      this.$emit('handleDelete', row)
    },
    handleCrc(row) {
      this.$emit('handleCrc', row)
    },
    handleSwitch(row, index) {
      this.$emit('handleSwitch', row, index)
    }
  }
}
</script>
<style lang="stylus">

</style>
