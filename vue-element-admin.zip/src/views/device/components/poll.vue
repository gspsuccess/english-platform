<template>
  <div>
    <el-row style="margin-bottom:12px">
      <el-button type="success" @click="handleAdd">新增记录</el-button>
      <el-button type="primary" style="margin-left:12px;" @click="handleSubmit">保存结果</el-button>
    </el-row>
    <el-row>
      <el-table :data="tableData" style="width: 100%" highlight-current-row border>
        <el-table-column label="描述">
          <template scope="scope">
            <el-input v-model="scope.row.descri" size="small" placeholder="请输入描述文字" />
          </template>
        </el-table-column>
        <el-table-column label="寄存器区分">
          <template scope="scope">
            <el-input v-model="scope.row.mbreg" size="small" placeholder="0:DO 1:DI 3:AI 4:HD" />
          </template>
        </el-table-column>
        <el-table-column label="起始地址">
          <template scope="scope">
            <el-input v-model="scope.row.mbaddr" size="small" placeholder="请输入起始地址" />
          </template>
        </el-table-column>
        <el-table-column label="扫描长度">
          <template scope="scope">
            <el-input v-model="scope.row.len" size="small" placeholder="请输入扫描长度" />
          </template>
        </el-table-column>
        <el-table-column label="扫描间隔时间">
          <template scope="scope">
            <el-input v-model="scope.row.interval_normal" size="small" placeholder="请输入扫描间隔时间" />
          </template>
        </el-table-column>
        <el-table-column label="操作">
          <template scope="scope">
            <!--<el-button size="small" @click="handleEdit(scope.$index, scope.row)">编辑</el-button>-->
            <el-button size="small" type="danger" @click="handleDelete(scope.$index, scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-row>
    <el-row v-if="total > pageSize" style="margin-top:12px">
      <el-pagination
        background
        layout="prev, pager, next"
        :page-size="pageSize"
        :current-page="currentPage"
        :total="total"
        @current-change="pageChange"
      />
    </el-row>
  </div>

</template>

<script type="text/ecmascript-6">
import { updateRtuPolls } from '@/api/device'

export default {
  props: ['device'],
  data() {
    return {
      currentPage: 1,
      pageSize: 10
    }
  },
  computed: {
    tableData() {
      if (this.device.rtu_polls) {
        const offset = (this.currentPage - 1) * this.pageSize
        return this.device.rtu_polls.slice(offset, offset + this.pageSize)
      }
      return []
    },
    total() {
      if (this.device.rtu_polls) {
        return this.device.rtu_polls.length
      }
      return 0
    }
  },
  methods: {
    handleAdd() {
      this.device.rtu_polls.push({
        serialno: this.device.serialno,
        descri: '',
        mbaddr: '',
        len: '',
        interval_normal: ''
      })
    },
    handleDelete(index, row) {
      this.device.rtu_polls.splice(index, 1)
    },
    async handleSubmit() {
      await updateRtuPolls(this.device.serialno, this.device.rtu_polls)
      this.$message.success('更新成功')
    },
    pageChange(current_page) {
      this.currentPage = current_page
    }
  }
}
</script>

<style scoped lang="stylus" rel="stylesheet/stylus">

</style>
