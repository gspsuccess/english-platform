<template>
  <div>
    <el-row style="margin-bottom:12px">
      <el-button type="success" @click="handleAdd">新增记录</el-button>
      <el-button type="primary" style="margin-left:12px;" @click="handleSubmit">保存结果</el-button>
    </el-row>
    <el-row>
      <el-table :data="tableData" style="width: 100%" highlight-current-row border>
        <el-table-column label="ID">
          <template scope="scope">
            <el-input v-model="scope.row.id" size="small" placeholder="请输入ID" />
          </template>
        </el-table-column>
        <el-table-column label="名称">
          <template scope="scope">
            <el-input v-model="scope.row.name" size="small" placeholder="请输入名称" />
          </template>
        </el-table-column>
        <el-table-column label="起始角度">
          <template scope="scope">
            <el-input v-model="scope.row.argstart" size="small" placeholder="请输入起始角度" />
          </template>
        </el-table-column>
        <el-table-column label="终止角度">
          <template scope="scope">
            <el-input v-model="scope.row.argend" size="small" placeholder="请输入终止角度" />
          </template>
        </el-table-column>
        <el-table-column label="起始喷头">
          <template scope="scope">
            <el-input v-model="scope.row.spstart" size="small" placeholder="请输入起始喷头号" />
          </template>
        </el-table-column>
        <el-table-column label="终止喷头">
          <template scope="scope">
            <el-input v-model="scope.row.spend" size="small" placeholder="请输入终止喷头号" />
          </template>
        </el-table-column>
        <el-table-column label="半径起始点">
          <template scope="scope">
            <el-input v-model="scope.row.disstart" size="small" placeholder="请输入半径起始点" />
          </template>
        </el-table-column>
        <el-table-column label="半径终点">
          <template scope="scope">
            <el-input v-model="scope.row.disend" size="small" placeholder="请输入半径终点" />
          </template>
        </el-table-column>
        <el-table-column label="排序">
          <template scope="scope">
            <el-input v-model="scope.row.idx" size="small" placeholder="请输入排序" />
          </template>
        </el-table-column>
        <el-table-column label="轮廓背景色">
          <template scope="scope">
            <el-input v-model="scope.row.color" size="small" placeholder="请输入轮廓背景色" />
          </template>
        </el-table-column>
        <el-table-column label="地图描画轮廓">
          <template scope="scope">
            <el-input v-model="scope.row.kml" size="small" placeholder="请输入地图描画轮廓" />
          </template>
        </el-table-column>
        <el-table-column label="操作">
          <template scope="scope">
            <!--<el-button size="small" @click="handleEdit(scope.$index, scope.row)">编辑</el-button>-->
            <el-button size="small" type="danger" @click="handleDelete(scope.$index, scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-row>
    <el-row v-if="total > pageSize" style="margin-top:12px">
      <el-pagination
        background
        layout="prev, pager, next"
        :page-size="pageSize"
        :current-page="currentPage"
        :total="total"
        @current-change="pageChange"
      />
    </el-row>
  </div>

</template>

<script type="text/ecmascript-6">
import { updateCells } from '@/api/device'

export default {
  props: ['device'],
  data() {
    return {
      currentPage: 1,
      pageSize: 10
    }
  },
  computed: {
    tableData() {
      if (this.device.cells) {
        const offset = (this.currentPage - 1) * this.pageSize
        return this.device.cells.slice(offset, offset + this.pageSize)
      }
      return []
    },
    total() {
      if (this.device.cells) {
        return this.device.cells.length
      }
      return 0
    }
  },
  methods: {
    handleAdd() {
      this.device.cells.push({
        serialno: this.device.serialno,
        id: '',
        name: '',
        argstart:'',
        argend:'',
        spstart:'',
        spend:'',
        disstart: '',
        disend: '',
        idx:'',
        color:'',
        kml:''
      })
    },
    handleDelete(index, row) {
      this.device.cells.splice(index, 1)
    },
    async handleSubmit() {
      await updateCells(this.device.serialno, this.device.cells)
      this.$message.success('更新成功')
    },
    pageChange(current_page) {
      this.currentPage = current_page
    }
  }
}
</script>

<style scoped lang="stylus" rel="stylesheet/stylus">

</style>
