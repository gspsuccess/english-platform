<template>
  <el-form ref="ruleForm" :model="formData" :rules="rules" label-width="100px" class="demo-ruleForm">
    <el-form-item label="项目地块" prop="projectsSelect">
      <el-cascader
        v-model="formData.projectsSelect"
        :options="projectsSelect"
        :props="props"
        @change="handleChange"
      />
    </el-form-item>
    <el-row>
      <el-col :span="12">
        <el-form-item label="设备型号" prop="product_id">
          <el-select v-model="formData.product_id" placeholder="请选择设备型号">
            <el-option v-for="(item,index) in products" :key="index" :label="item.name" :value="item.id" />
          </el-select>
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="网关ID" prop="scada_id">
          <el-input v-model="formData.scada_id" autocomplete="off" placeholder="请输入网关ID" />
        </el-form-item>
      </el-col>
    </el-row>
    <el-row>
      <el-form-item label="设备数量" prop="amount">
      <el-input-number v-model="formData.amount" :min="1" :max="100"></el-input-number>
      </el-form-item>
    </el-row>
    <el-form-item>
      <el-button type="primary" @click="submitForm('ruleForm')">提交</el-button>
      <el-button @click="resetForm('ruleForm')">重置</el-button>
    </el-form-item>
  </el-form>
</template>

<script type="text/ecmascript-6">
export default {
  props: {
    formData: {
      type: Object,
      default() {
        return {}
      }
    },
    projects: {
      type: Array,
      default() {
        return []
      }
    },
    fields: {
      type: Array,
      default() {
        return []
      }
    },
    products: {
      type: Array,
      default() {
        return []
      }
    },
    devices: {
      type: Array,
      default() {
        return []
      }
    },
    projectsSelect: {
      type: Array,
      default() {
        return []
      }
    }
  },
  data() {
    return {
      props: {
        label: 'name',
        value: 'id',
        children: 'fields'
      },
      imageUrl: '',
      rules: {
        name: [
          { required: true, message: '请输入设备名称', trigger: 'blur' }
        ],
        serialno: [
          { required: true, message: '请输入设备编号', trigger: 'blur' }
        ],
        product_id: [
          { required: true, message: '请选择设备型号', trigger: 'blur' }
        ],
        projectsSelect: [
          { required: true, message: '请选择所属项目地块', trigger: 'blur' }
        ],
        scada_id: [
          { required: true, message: '请输入网关ID', trigger: 'blur' }
        ]
      },
      options: []
    }
  },
  watch: {
    formData() {
      this.formData.projectsSelect = [this.formData.project_id,this.formData.field_id]
      console.log(this.formData)
    }
  },
  methods: {
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.$emit('handleSubmit', this.formData)
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    resetForm(formName) {
      this.$refs[formName].resetFields()
    },
    handleChange(e) {
      this.formData.project_id = e[0]
      this.formData.field_id = e[1]
    }
  }
}
</script>

<style scoped lang="stylus" rel="stylesheet/stylus">

</style>
