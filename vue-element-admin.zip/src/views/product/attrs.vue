<template>
  <div class="attrs-wrapper">
    <el-tabs v-model="activeName" type="border-card" @tab-click="handleClick">
      <el-tab-pane label="产品属性" name="first">
        <el-row>
          <el-form :model="formProduct" :label-width="formLabelWidth">
            <el-form-item label="生产厂家">
              <el-select v-model="formProduct.maker" placeholder="请选择生产厂家">
                <el-option
                  v-for="(item,index) in makers"
                  :key="index"
                  :label="item.name"
                  :value="item.id"
                />
              </el-select>
            </el-form-item>
            <el-form-item label="设备类型">
              <el-select v-model="formProduct.product_type" placeholder="请选择设备类型">
                <el-option
                  v-for="(item,index) in product_types"
                  :key="index"
                  :label="item.name"
                  :value="item.id"
                />
              </el-select>
            </el-form-item>
            <el-form-item label="产品名称">
              <el-input v-model="formProduct.name" placeholder="请输入产品名称" autocomplete="off" />
            </el-form-item>
            <el-form-item label="产品型号">
              <el-input v-model="formProduct.model" placeholder="请输入设备编号" autocomplete="off" />
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="submit">确 定</el-button>
            </el-form-item>
          </el-form>
        </el-row>
      </el-tab-pane>
      <el-tab-pane label="产品规格" name="second">
        <spec :product="product" />
      </el-tab-pane>
      <el-tab-pane label="产品指令" name="third">
        <action :product="product" />
      </el-tab-pane>
      <el-tab-pane label="产品端口" name="fourth">
        <property :product="product" />
      </el-tab-pane>
      <el-tab-pane label="扫描序列" name="fifth">
        <poll :product="product" />
      </el-tab-pane>
      <el-tab-pane label="端口显示集" name="sixth">
        <portDisplay :product="product" />
      </el-tab-pane>
      <el-tab-pane label="指令显示集" name="seventh">
        <actionDisplay :product="product" />
      </el-tab-pane>
    </el-tabs>
  </div>
</template>
<script>
import poll from './components/poll'
import spec from './components/spec'
import action from './components/action'
import property from './components/property'
import actionDisplay from './components/actionDisplay'
import portDisplay from './components/portDisplay'
import { getProductTypes, getMakers } from '@/api/basedata'
import { product, updateProduct } from '@/api/product'
export default {
  components: {
    poll,
    spec,
    action,
    property,
    portDisplay,
    actionDisplay
  },
  data() {
    return {
      activeName: 'first',
      formLabelWidth: '120px',
      product_types: [],
      makers: [],
      product: {},
      formProduct: {
        id: '',
        name: '',
        maker: '',
        product_type: '',
        model: ''
      }
    }
  },
  watch: {
    product() {
      const product = this.product
      this.formProduct = {
        id: product.id,
        name: product.name,
        maker: product.maker.val,
        product_type: product.product_type.val,
        model: product.model
      }
    }
  },
  created() {
    this.getBaseData()
    const id = this.$route.query.id
    this.getProduct(id)
  },
  methods: {
    async getBaseData() {
      const product_types = await getProductTypes()
      const makers = await getMakers()
      this.product_types = product_types.data
      this.makers = makers.data
    },
    async getProduct(id) {
      const { data } = await product(id)
      this.product = data
    },
    handleClick(tab, event) {
      console.log(tab, event)
    },
    async submit() {
      await updateProduct(this.product.id, this.formProduct)
      this.$message.success('更新成功')
    }
  }
}
</script>

<style scoped lang="stylus" rel="stylesheet/stylus">
.attrs-wrapper
  padding 16px
</style>
