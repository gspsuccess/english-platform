<template>
  <div class="app-container">
    <el-form :inline="true" :model="formProductSearch" class="demo-form-inline">
      <el-form-item>
        <el-select v-model="formProductSearch.maker" placeholder="生产厂家">
          <el-option
            v-for="item in makers"
            :key="item.id"
            :label="item.name"
            :value="item.id"
          />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-select v-model="formProductSearch.product_type" placeholder="产品类型">
          <el-option
            v-for="item in product_types"
            :key="item.id"
            :label="item.name"
            :value="item.id"
          />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-input v-model="formProductSearch.name" placeholder="产品名称" />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="handleSearch">查询</el-button>
        <el-button icon="el-icon-plus" type="primary" @click="handleAdd">新增产品</el-button>
      </el-form-item>
    </el-form>
    <el-table :data="list.data" stripe border style="width: 100%">
      <el-table-column sortable align="center" prop="id" label="id" width="80" />
      <el-table-column align="center" prop="name" label="产品名称" />
      <el-table-column sortable align="center" prop="product_type.txt" label="设备类型" />
      <el-table-column sortable align="center" prop="maker.txt" label="生产厂家" />
      <el-table-column sortable align="center" prop="model" label="产品型号" />
      <el-table-column sortable align="center" prop="created_at" label="创建时间" />
      <el-table-column label="操作" align="center">
        <template slot-scope="scope">
          <el-button size="mini" type="default" @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
          <el-button size="mini" type="danger" @click="handleDelete(scope.$index, scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div style="border:1px solid #ddd;border-top:0;padding:16px 4px">
      <el-pagination
        background
        layout="prev, pager, next"
        :page-size="list.per_page"
        :current-page="list.current_page"
        :page-count="list.last_page"
        :total="list.total"
        @current-change="pageChange"
      />
    </div>
    <el-dialog title="上传产品属性模板" :visible.sync="dialogFormVisible">
      <file-upload />
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="uploadSuccess">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { products, deleteProduct } from '@/api/product'
import { getProductTypes, getMakers } from '@/api/basedata'
import { MessageBox, Message } from 'element-ui'
import FileUpload from '@/components/FileUpload'

export default {
  name: 'ProductTable',
  components: {
    FileUpload
  },
  data() {
    return {
      dialogFormVisible: false,
      formLabelWidth: '120px',
      makers: [],
      product_types: [],
      formProductSearch: {},
      tableData: [],
      list: [],
      listLoading: true,
      listQuery: {
        page: 1,
        limit: 10
      }
    }
  },
  created() {
    this.getList()
    this.getBaseData()
  },
  methods: {
    uploadSuccess() {
      this.dialogFormVisible = false
      this.getList()
    },
    async getBaseData() {
      const product_types = await getProductTypes()
      const makers = await getMakers()
      this.product_types = product_types.data
      this.makers = makers.data
    },
    async getList() {
      this.listLoading = true
      const { data } = await products(this.listQuery)
      this.list = data
    },
    pageChange(current_page) {
      this.listQuery.page = current_page
      this.getList()
    },
    async handleSearch() {
      const params = Object.assign(this.formProductSearch, this.listQuery)
      const data = await products(params)
      console.log(data)
    },
    handleAdd() {
      this.dialogFormVisible = true
    },
    handleEdit(index, row) {
      this.$router.push({ path: '/product/attrs', query: { id: row.id }})
    },
    async handleDelete(index, row) {
      MessageBox.confirm('确定要删除该条记录吗？', '删除确认', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.listLoading = true
        deleteProduct(row.id)

        Message({
          message: '操作成功',
          type: 'success',
          duration: 5 * 1000,
          onClose: () => {
            this.getList()
          }
        })
      })
    }
  }
}
</script>

<style scoped>

</style>
