<template>
  <div>
    <el-row style="margin-bottom:12px">
      <el-button type="success" @click="handleAdd">新增记录</el-button>
      <el-button type="primary" style="margin-left:12px;" @click="handleSubmit">保存结果</el-button>
    </el-row>
    <el-row>
      <el-table :data="tableData" class="tb-edit" style="width: 100%" highlight-current-row border>
        <el-table-column label="属性名">
          <template scope="scope">
            <el-input v-model="scope.row.name" size="small" placeholder="请输入属性名" />
          </template>
        </el-table-column>
        <el-table-column label="属性值">
          <template scope="scope">
            <el-input v-model="scope.row.value" size="small" placeholder="请输入属性值" />
          </template>
        </el-table-column>
        <el-table-column label="操作">
          <template scope="scope">
            <!--<el-button size="small" @click="handleEdit(scope.$index, scope.row)">编辑</el-button>-->
            <el-button size="small" type="danger" @click="handleDelete(scope.$index, scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-row>
    <el-row v-if="total > pageSize" style="margin-top:12px">
      <el-pagination
        background
        layout="prev, pager, next"
        :page-size="pageSize"
        :current-page="currentPage"
        :total="total"
        @current-change="pageChange"
      />
    </el-row>
  </div>
</template>

<script type="text/ecmascript-6">
import { updateProductSpecs } from '@/api/product'
export default {
  props: ['product'],
  data() {
    return {
      currentPage: 1,
      pageSize: 10
    }
  },
  computed: {
    tableData() {
      if (this.product.spec) {
        const offset = (this.currentPage - 1) * this.pageSize
        return this.product.spec.slice(offset, offset + this.pageSize)
      }
      return []
    },
    total() {
      if (this.product.spec) {
        return this.product.spec.length
      }
      return 0
    }
  },
  methods: {
    handleAdd() {
      this.product.spec.push({ name: '', value: '' })
    },
    handleDelete(index, row) {
      this.product.spec.splice(index, 1)
    },
    async handleSubmit() {
      await updateProductSpecs(this.product.id, this.product.spec)
      this.$message.success('更新成功')
    },
    pageChange(current_page) {
      this.currentPage = current_page
    }
  }
}
</script>

<style scoped lang="stylus" rel="stylesheet/stylus">

</style>
