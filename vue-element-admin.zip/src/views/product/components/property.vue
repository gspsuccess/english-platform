<template>
  <div>
    <el-row style="margin-bottom:12px">
      <el-button type="success" @click="handleAdd">新增记录</el-button>
      <el-button type="primary" style="margin-left:12px;" @click="handleSubmit">保存结果</el-button>
    </el-row>
    <el-row>
      <el-table :data="tableData" style="width: 100%" highlight-current-row border>
        <el-table-column label="name">
          <template scope="scope">
            <el-input v-model="scope.row.name" size="small" placeholder="名称" />
          </template>
        </el-table-column>
        <el-table-column label="namekey">
          <template scope="scope">
            <el-input v-model="scope.row.namekey" size="small" placeholder="外部参考名" />
          </template>
        </el-table-column>
        <el-table-column label="mbreg">
          <template scope="scope">
            <el-input v-model="scope.row.mbreg" size="small" placeholder="寄存器区分" />
          </template>
        </el-table-column>
        <el-table-column label="mbreg_to">
          <template scope="scope">
            <el-input v-model="scope.row.mbreg_to" size="small" placeholder="转义类型" />
          </template>
        </el-table-column>
        <el-table-column label="namekey_to">
          <template scope="scope">
            <el-input v-model="scope.row.namekey_to" size="small" placeholder="转义名称" />
          </template>
        </el-table-column>
        <el-table-column label="mbaddr">
          <template scope="scope">
            <el-input v-model="scope.row.mbaddr" size="small" placeholder="寄存器地址" />
          </template>
        </el-table-column>
        <el-table-column label="mblen">
          <template scope="scope">
            <el-input v-model="scope.row.mblen" size="small" placeholder="字长" />
          </template>
        </el-table-column>
        <el-table-column label="mbtype">
          <template scope="scope">
            <el-input v-model="scope.row.mbtype" size="small" placeholder="数据类型" />
          </template>
        </el-table-column>
        <el-table-column label="mbswap">
          <template scope="scope">
            <el-input v-model="scope.row.mbswap" size="small" placeholder="是否反转" />
          </template>
        </el-table-column>
        <el-table-column label="unit">
          <template scope="scope">
            <el-input v-model="scope.row.unit" size="small" placeholder="单位" />
          </template>
        </el-table-column>
        <el-table-column label="kunit">
          <template scope="scope">
            <el-input v-model="scope.row.kunit" size="small" placeholder="表示比例" />
          </template>
        </el-table-column>
        <el-table-column label="kval1">
          <template scope="scope">
            <el-input v-model="scope.row.kval1" size="small" placeholder="1次系数" />
          </template>
        </el-table-column>
        <el-table-column label="kval2">
          <template scope="scope">
            <el-input v-model="scope.row.kval2" size="small" placeholder="2次系数" />
          </template>
        </el-table-column>
        <el-table-column label="koffset">
          <template scope="scope">
            <el-input v-model="scope.row.koffset" size="small" placeholder="偏移量" />
          </template>
        </el-table-column>
        <el-table-column label="kmod">
          <template scope="scope">
            <el-input v-model="scope.row.kmod" size="small" placeholder="取模" />
          </template>
        </el-table-column>
        <el-table-column label="操作">
          <template scope="scope">
            <!--<el-button size="small" @click="handleEdit(scope.$index, scope.row)">编辑</el-button>-->
            <el-button size="small" type="danger" @click="handleDelete(scope.$index, scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-row>
    <el-row v-if="total > pageSize" style="margin-top:12px">
      <el-pagination
        background
        layout="prev, pager, next"
        :page-size="pageSize"
        :current-page="currentPage"
        :total="total"
        @current-change="pageChange"
      />
    </el-row>
  </div>
</template>

<script type="text/ecmascript-6">
import { updateProductProperties } from '@/api/product'
export default {
  props: ['product'],
  data() {
    return {
      currentPage: 1,
      pageSize: 10
    }
  },
  computed: {
    tableData() {
      if (this.product.properties) {
        const offset = (this.currentPage - 1) * this.pageSize
        return this.product.properties.slice(offset, offset + this.pageSize)
      }
      return []
    },
    total() {
      if (this.product.properties) {
        return this.product.properties.length
      }
      return 0
    }
  },
  methods: {
    handleAdd() {
      this.product.properties.push({
        name: '',
        namekey: '',
        mbreg: '',
        mbaddr: '',
        mblen: '',
        mbtype: '',
        mbswap: '',
        unit: '',
        kval1: '',
        kval2: '',
        koffset: '',
        kmod: ''
      })
    },
    handleDelete(index, row) {
      this.product.properties.splice(index, 1)
    },
    async handleSubmit() {
      await updateProductProperties(this.product.id, this.product.properties)
      this.$message.success('更新成功')
    },
    pageChange(current_page) {
      this.currentPage = current_page
    }
  }
}
</script>

<style scoped lang="stylus" rel="stylesheet/stylus">

</style>
