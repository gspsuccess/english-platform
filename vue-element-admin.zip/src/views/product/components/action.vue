<template>
  <div>
    <el-row style="margin-bottom:12px">
      <el-button type="success" @click="handleAdd">新增记录</el-button>
      <el-button type="primary" style="margin-left:12px;" @click="handleSubmit">保存结果</el-button>
    </el-row>
    <el-row>
      <el-table :data="tableData" style="width: 100%" highlight-current-row border>
        <el-table-column label="指令名（中文）">
          <template scope="scope">
            <el-input v-model="scope.row.name" size="small" placeholder="请输入描述文字" />
          </template>
        </el-table-column>
        <el-table-column label="指令名">
          <template scope="scope">
            <el-input v-model="scope.row.namekey" size="small" placeholder="请输入起始地址" />
          </template>
        </el-table-column>
        <el-table-column label="指令地址">
          <template scope="scope">
            <el-input v-model="scope.row.params.addr" size="small" placeholder="请输入扫描长度" />
          </template>
        </el-table-column>
        <el-table-column label="指令长度">
          <template scope="scope">
            <el-input v-model="scope.row.params.len" size="small" placeholder="请输入扫描间隔时间" />
          </template>
        </el-table-column>
        <el-table-column label="指令类型">
          <template scope="scope">
            <el-input v-model="scope.row.params.cmd" size="small" placeholder="请输入扫描间隔时间" />
          </template>
        </el-table-column>
        <el-table-column label="指令值">
          <template scope="scope">
            <el-input v-model="scope.row.params.val" size="small" placeholder="请输入扫描间隔时间" />
          </template>
        </el-table-column>
        <el-table-column label="操作">
          <template scope="scope">
            <!--<el-button size="small" @click="handleEdit(scope.$index, scope.row)">编辑</el-button>-->
            <el-button size="small" type="danger" @click="handleDelete(scope.$index, scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-row>
    <el-row v-if="total > pageSize" style="margin-top:12px">
      <el-pagination
        background
        layout="prev, pager, next"
        :page-size="pageSize"
        :current-page="currentPage"
        :total="total"
        @current-change="pageChange"
      />
    </el-row>
  </div>
</template>

<script type="text/ecmascript-6">
import { updateProductActions } from '@/api/product'
export default {
  props: ['product'],
  data() {
    return {
      currentPage: 1,
      pageSize: 10
    }
  },
  computed: {
    tableData() {
      if (this.product.actions) {
        const offset = (this.currentPage - 1) * this.pageSize
        return this.product.actions.slice(offset, offset + this.pageSize)
      }
      return []
    },
    total() {
      if (this.product.actions) {
        return this.product.actions.length
      }
      return 0
    }
  },
  methods: {
    handleAdd() {
      this.product.actions.push({
        name: '',
        namekey: '',
        params: {
          addr: '',
          len: '',
          cmd: '',
          val: ''
        }
      })
    },
    handleDelete(index, row) {
      this.product.actions.splice(index, 1)
    },
    async handleSubmit() {
      await updateProductActions(this.product.id, this.product.actions)
      this.$message.success('更新成功')
    },
    pageChange(current_page) {
      this.currentPage = current_page
    }
  }
}
</script>

<style scoped lang="stylus" rel="stylesheet/stylus">

</style>
