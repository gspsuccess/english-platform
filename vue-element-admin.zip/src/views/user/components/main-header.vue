<template>
  <el-form :inline="true" :model="searchForm">
    <el-form-item>
      <el-select v-model="searchForm.user_group_id" placeholder="请选择所属用户组">
        <el-option v-for="(item,index) in userGroups" :key="index" :label="item.name" :value="item.id" />
      </el-select>
    </el-form-item>
    <el-form-item>
      <el-input v-model="searchForm.name" placeholder="用户名称" />
    </el-form-item>
    <el-form-item>
      <el-input v-model="searchForm.phone" placeholder="手机号" />
    </el-form-item>
    <el-form-item>
      <el-input v-model="searchForm.email" placeholder="邮箱" />
    </el-form-item>
    <el-form-item>
      <el-button type="primary" @click="handleSearch">查询</el-button>
    </el-form-item>
  </el-form>
</template>

<script type="text/ecmascript-6">
export default {
  props: ['userGroups'],
  data() {
    return {
      searchForm: {}
    }
  },
  methods: {
    handleSearch() {
      this.$emit('handleSearch', this.searchForm)
    },
    openDialog() {
      this.$emit('openDialog')
    }
  }
}
</script>

<style scoped lang="stylus" rel="stylesheet/stylus">

</style>
