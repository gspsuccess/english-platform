<template>
  <el-table :data="tableData" style="width: 100%" border :default-sort="{prop: 'date', order: 'descending'}">
    <el-table-column align="center" prop="name" label="名称" :formatter="formatter" />
    <el-table-column align="center" prop="avatar" label="头像" :formatter="formatter" sortable>
      <template slot-scope="scope">
        <span><img v-real-img="scope.row.avatar" src="http://cdn.yuuleyou.com/noimg.png" class="small" alt=""></span>
      </template>
    </el-table-column>
    <el-table-column align="center" prop="user_group_id" label="所属用户组" :formatter="formatter" sortable>
      <template slot-scope="scope">
        <span>{{ scope.row.userGroup?scope.row.userGroup.name:'--' }}</span>
      </template>
    </el-table-column>
    <el-table-column align="center" prop="phone" label="手机号" :formatter="formatter" sortable />
    <el-table-column align="center" prop="status" label="状态" sortable>
      <template slot-scope="scope">
        <el-switch
          v-model="scope.row.status"
          active-color="#13ce66"
          inactive-color="#bababa"
          :active-value="1"
          :inactive-value="0"
        />
      </template>
    </el-table-column>
    <el-table-column align="center" prop="created_at" label="注册时间" :formatter="formatter" sortable />
    <el-table-column align="center" label="操作">
      <template slot-scope="scope">
        <el-button size="mini" @click="handleEdit(scope.row)">编辑</el-button>
        <el-button size="mini" type="danger" @click="handleDelete(scope.row)">删除</el-button>
      </template>
    </el-table-column>
  </el-table>
</template>

<script>
export default {
  props: {
    listObj: {
      type: Object,
      default() {
        return {}
      }
    }
  },
  data() {
    return {}
  },
  computed: {
    tableData() {
      let result = []
      if (this.listObj.data) {
        result = this.listObj.data.data
      }

      return result
    }
  },
  methods: {
    formatter(row, column) {
      return row[column.property] ? row[column.property] : '--'
    },
    handleEdit(row) {
      this.$emit('handleEdit', row)
    },
    handleDelete(row) {
      this.$emit('handleDelete', row)
    }
  }
}
</script>
<style lang="stylus">

</style>
