<template>
  <div class="app-container">
    <main-header :user-groups="userGroups" @openDialog="openDialog" @handleSearch="handleSearch" />
    <el-row>
      <list :list-obj="listObj" @handleEdit="handleEdit" @handleDelete="handleDelete" />
      <page-container :list-obj="listObj" @changeCurrentPage="changeCurrentPage" />
    </el-row>
    <el-dialog :title="title" :visible.sync="dialogFormVisible">
      <main-form
        ref="child"
        :form-data="formData"
        :user-groups="userGroups"
        @handleSubmit="handleSubmit"
      />
    </el-dialog>
  </div>
</template>

<script type="text/ecmascript-6">
import mainHeader from './components/main-header'
import list from './components/list'
import mainForm from './components/main-form'
import PageContainer from '@/components/PageContainer'
import { getAll, getOne, addOne, updateOne, deleteOne } from '@/api/user'
import { getUserGroups } from '@/api/basedata'

const formData = {
  name: '',
  user_group_id: '',
  avatar: '',
  phone: '',
  email: '',
  lng: '',
  kml: '',
  icon_uri: '',
  descri: ''
}
export default {
  components: {
    mainHeader,
    list,
    mainForm,
    PageContainer
  },
  data() {
    return {
      title: '',
      dialogFormVisible: false,
      formData: formData,
      listObj: {},
      listQuery: {
        page: 1
      },
      userGroups: []
    }
  },
  created() {
    this.getList()
    this.getBaseData()
  },
  methods: {
    async getList() {
      const listObj = await getAll(this.listQuery)
      this.listObj = listObj
    },
    async getBaseData() {
      const userGroups = await getUserGroups()
      this.userGroups = userGroups.data
    },
    changeCurrentPage(page) {
      this.listQuery.page = page
      this.getList()
    },
    openDialog() {
      this.title = '新增记录'
      this.formData = formData
      this.dialogFormVisible = true
    },
    handleSearch(data) {
      this.listQuery = Object.assign(this.listQuery, data)
      this.getList()
    },
    handleSubmit(model) {
      if (this.title === '新增记录') {
        addOne(model).then((res) => {
          if (res.errorCode === 0) {
            this.$message.success(res.msg)
            this.resetForm()
          }
        })
      }
      if (this.title === '修改记录') {
        updateOne(model.id, model).then((res) => {
          if (res.errorCode === 0) {
            this.$message.success(res.msg)
            this.resetForm()
          }
        })
      }
    },
    handleEdit(row) {
      this.title = '修改记录'
      this.dialogFormVisible = true
      getOne(row.id).then((res) => {
        if (res.errorCode === 0) {
          this.formData = res.data
        }
      })
    },
    handleDelete(row) {
      this.$confirm('此操作将永久删除该条记录, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteOne(row.id).then((res) => {
          if (res.errorCode === 0) {
            this.$message.success(res.msg)
            this.getList()
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    resetForm() {
      this.getList()
      this.dialogFormVisible = false
      this.$refs.child.resetForm('ruleForm')
    }
  }
}
</script>

<style scoped lang="stylus" rel="stylesheet/stylus">

</style>
