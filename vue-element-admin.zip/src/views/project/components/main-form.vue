<template>
  <el-form ref="ruleForm" :model="formData" :rules="rules" label-width="100px" class="demo-ruleForm">
    <el-row>
      <el-col :span="12">
        <el-form-item label="项目名称" prop="name">
          <el-input v-model="formData.name" placeholder="请输入项目名称" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="所属用户组">
          <el-select v-model="formData.user_group_id" placeholder="请选择所属用户组">
            <el-option v-for="(item,index) in userGroups" :key="index" :label="item.name" :value="item.id" />
          </el-select>
        </el-form-item>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="12">
        <el-form-item label="所在地址" prop="address">
          <el-input v-model="formData.address" placeholder="请输入项目所在地址" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="电话" prop="tel">
          <el-input v-model="formData.tel" placeholder="请输入项目负责人电话" />
        </el-form-item>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="12">
        <el-form-item label="经度" prop="lng">
          <el-input v-model="formData.lng" placeholder="请输入项目所在经度" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="纬度" prop="lat">
          <el-input v-model="formData.lat" placeholder="请输入项目所在纬度" />
        </el-form-item>
      </el-col>
    </el-row>
    <el-form-item label="项目图片">
      <ImgUpload name="project" :image-url="imageUrl" @onSuccess="onSuccess" @beforeUpload="beforeUpload" />
    </el-form-item>
    <el-form-item label="备注说明" prop="descri">
      <el-input v-model="formData.descri" type="textarea" placeholder="请输入备注说明" />
    </el-form-item>
    <el-form-item label="kml信息" prop="kml">
      <el-input v-model="formData.kml" type="textarea" placeholder="请输入kml信息" />
    </el-form-item>
    <el-form-item>
      <el-button type="primary" @click="submitForm('ruleForm')">提交</el-button>
      <el-button @click="resetForm('ruleForm')">重置</el-button>
    </el-form-item>
  </el-form>
</template>

<script>
import ImgUpload from '@/components/ImgUpload'

export default {
  components: {
    ImgUpload
  },
  props: ['formData', 'userGroups'],
  data() {
    return {
      rules: {
        name: [{ required: true, message: '请输入项目名称', trigger: 'blur' }],
        phone: [
          { required: true, message: '请输入项目负责人电话', trigger: 'blur' }
        ],
        lng: [
          { required: true, message: '请输入项目经度信息', trigger: 'blur' }
        ],
        lat: [
          { required: true, message: '请输入项目纬度信息', trigger: 'blur' }
        ]
      }
    }
  },
  computed: {
    imageUrl() {
      if (this.formData.icon_uri) {
        let prefix = ''
        if (!/http:\/\/|https:\/\//.test(this.formData.icon_uri)) {
          prefix = 'https://api.zesi.com.cn'
        }
        return prefix + this.formData.icon_uri
      }
      return ''
    }
  },
  methods: {
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.$emit('handleSubmit', this.formData)
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    resetForm(formName) {
      this.$refs[formName].resetFields()
    },
    onSuccess(data) {
      this.formData.icon_uri = data
    },
    beforeUpload(file) {
      const isJPG = file.type === 'image/jpeg'
      const isLt2M = file.size / 1024 / 1024 < 2

      if (!isJPG) {
        this.$message.error('上传头像图片只能是 JPG 格式!')
      }
      if (!isLt2M) {
        this.$message.error('上传头像图片大小不能超过 2MB!')
      }
      return isJPG && isLt2M
    }
  }
}
</script>
<style lang="stylus">
</style>
