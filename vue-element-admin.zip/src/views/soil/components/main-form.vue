<template>
  <el-form ref="ruleForm" :model="formData" :rules="rules" label-width="100px" class="demo-ruleForm">
    <el-row>
      <el-col :span="12">
        <el-form-item label="土壤名称" prop="name">
          <el-input v-model="formData.name" placeholder="请输入土壤名称" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="容重" prop="unit_weight">
          <el-input v-model="formData.unit_weight" placeholder="请输入土壤容重" />
        </el-form-item>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="12">
        <el-form-item label="田间持水量" prop="field_capacity">
          <el-input v-model="formData.field_capacity" placeholder="请输入田间持水量" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="凋萎系数">
          <el-input v-model="formData.wilting_coefficient" placeholder="请输入凋萎系数" />
        </el-form-item>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="12">
        <el-form-item label="饱和含水率">
          <el-input v-model="formData.water_content" placeholder="请输入饱和含水率" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="地表径流">
          <el-input v-model="formData.runoff_curve" placeholder="请输入地表径流" />
        </el-form-item>
      </el-col>
    </el-row>
    <el-form-item label="土壤图片">
      <ImgUpload name="soil" :image-url="imageUrl" @onSuccess="onSuccess" @beforeUpload="beforeUpload" />
    </el-form-item>
    <el-form-item label="备注说明" prop="descri">
      <el-input v-model="formData.descri" type="textarea" placeholder="请输入备注说明" rows="4" />
    </el-form-item>
    <el-form-item>
      <el-button type="primary" @click="submitForm('ruleForm')">提交</el-button>
      <el-button @click="resetForm('ruleForm')">重置</el-button>
    </el-form-item>
  </el-form>
</template>

<script>
import ImgUpload from '@/components/ImgUpload'

export default {
  components: {
    ImgUpload
  },
  props: ['formData'],
  data() {
    return {
      rules: {
        name: [
          { required: true, message: '请输入土壤名称', trigger: 'blur' }
        ],
        unit_weight: [
          { required: true, message: '请输入土壤容重', trigger: 'blur' }
        ],
        field_capacity: [
          { required: true, message: '请输入田间持水量', trigger: 'blur' }
        ],
        descri: [
          { required: true, message: '请输入备注说明', trigger: 'blur' }
        ]
      }
    }
  },
  computed: {
    imageUrl() {
      if (this.formData.picture) {
        let prefix = ''
        if (!/http:\/\/|https:\/\//.test(this.formData.picture)) {
          prefix = 'https://api.zesi.com.cn'
        }
        return prefix + this.formData.picture
      }
      return ''
    }
  },
  methods: {
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.$emit('handleSubmit', this.formData)
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    resetForm(formName) {
      this.$refs[formName].resetFields()
    },
    onSuccess(data) {
      this.formData.picture = data
    },
    beforeUpload(file) {
      const isJPG = file.type === 'image/jpeg'
      const isLt2M = file.size / 1024 / 1024 < 2

      if (!isJPG) {
        this.$message.error('上传头像图片只能是 JPG 格式!')
      }
      if (!isLt2M) {
        this.$message.error('上传头像图片大小不能超过 2MB!')
      }
      return isJPG && isLt2M
    }
  }
}
</script>
<style lang="stylus">

</style>
