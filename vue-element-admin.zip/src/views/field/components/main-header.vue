<template>
  <el-row>
    <el-col :span="20">
      <el-form :inline="true" :model="searchForm">
        <el-form-item>
          <el-cascader v-model="searchForm.region_id" :options="regions" clearable placeholder="请选择所在地区" />
        </el-form-item>
        <el-form-item>
          <el-select v-model="searchForm.project_id" placeholder="请选择所项目">
            <el-option v-for="(item,index) in projects" :key="index" :label="item.name" :value="item.id" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-select v-model="searchForm.soil_id" placeholder="请选择土壤类型">
            <el-option v-for="(item,index) in soils" :key="index" :label="item.name" :value="item.id" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-input v-model="searchForm.name" placeholder="地块名称" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="handleSearch">查询</el-button>
        </el-form-item>
      </el-form>
    </el-col>
    <el-col :span="4">
      <el-button type="success" style="float:right" @click="openDialog"><i class="el-icon-plus" />新增记录</el-button>
    </el-col>
  </el-row>
</template>

<script type="text/ecmascript-6">
export default {
  props: ['regions', 'projects', 'soils'],
  data() {
    return {
      searchForm: {},
      options: []
    }
  },
  methods: {
    handleSearch() {
      this.$emit('handleSearch', this.searchForm)
    },
    openDialog() {
      this.$emit('openDialog')
    }
  }
}
</script>

<style scoped lang="stylus" rel="stylesheet/stylus">

</style>
