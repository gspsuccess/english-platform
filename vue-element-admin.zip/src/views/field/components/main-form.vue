<template>
  <el-form ref="ruleForm" :model="formData" :rules="rules" label-width="100px" class="demo-ruleForm">
    <el-row>
      <el-col :span="12">
        <el-form-item label="地块名称" prop="name">
          <el-input v-model="formData.name" placeholder="请输入地块名称" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="土壤类型">
          <el-select v-model="formData.soil_id" placeholder="请选择土壤类型">
            <el-option v-for="(item,index) in soils" :key="index" :label="item.name" :value="item.id" />
          </el-select>
        </el-form-item>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="12">
        <el-form-item label="所在地区">
          <el-cascader v-model="formData.region_id" :options="regions" clearable />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="所属项目" prop="project_id">
          <el-select v-model="formData.project_id" placeholder="请选择所属项目">
            <el-option v-for="(item,index) in projects" :key="index" :label="item.name" :value="item.id" />
          </el-select>
        </el-form-item>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="12">
        <el-form-item label="地址" prop="address">
          <el-input v-model="formData.address" placeholder="请输入地块所在地址" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="高程" prop="ele">
          <el-input v-model="formData.ele" placeholder="请输入高程" />
        </el-form-item>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="12">
        <el-form-item label="经度" prop="lng">
          <el-input v-model="formData.lng" placeholder="请输入项目所在经度" />
        </el-form-item>
      </el-col>
      <el-col :span="12">
        <el-form-item label="纬度" prop="lat">
          <el-input v-model="formData.lat" placeholder="请输入项目所在纬度" />
        </el-form-item>
      </el-col>
    </el-row>
    <el-form-item label="kml信息" prop="kml">
      <el-input v-model="formData.kml" type="textarea" placeholder="请输入kml信息" />
    </el-form-item>
    <el-form-item>
      <el-button type="primary" @click="submitForm('ruleForm')">提交</el-button>
      <el-button @click="resetForm('ruleForm')">重置</el-button>
    </el-form-item>
  </el-form>
</template>

<script>
export default {
  props: {
    formData: {
      type: Object,
      default() {
        return []
      }
    },
    soils: {
      type: Array,
      default() {
        return []
      }
    },
    projects: {
      type: Array,
      default() {
        return []
      }
    },
    regions: {
      type: Array,
      default() {
        return []
      }
    }
  },
  data() {
    return {
      imageUrl: '',
      rules: {
        name: [
          { required: true, message: '请输入地块名称', trigger: 'blur' }
        ],
        project_id: [
          { required: true, message: '请选择所属项目', trigger: 'blur' }
        ],
        lng: [
          { required: true, message: '请输入地块经度信息', trigger: 'blur' }
        ],
        lat: [
          { required: true, message: '请输入地块纬度信息', trigger: 'blur' }
        ]
      },
      options: []
    }
  },
  methods: {
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.$emit('handleSubmit', this.formData)
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    resetForm(formName) {
      this.$refs[formName].resetFields()
    }
  }
}
</script>
<style lang="stylus">

</style>
