<template>
  <el-table :data="tableData" style="width: 100%" border :default-sort="{prop: 'date', order: 'descending'}">
    <el-table-column align="center" prop="name" label="名称" :formatter="formatter" />
    <el-table-column align="center" prop="project_id" label="所属项目" :formatter="formatter" sortable>
      <template slot-scope="scope">
        <span>{{ scope.row.project?scope.row.project.name:'--' }}</span>
      </template>
    </el-table-column>
    <el-table-column align="center" prop="region_text" label="所在地区" :formatter="formatter" sortable />
    <el-table-column align="center" prop="soil_id" label="土壤类型" :formatter="formatter" sortable>
      <template slot-scope="scope">
        <span>{{ scope.row.soil?scope.row.soil.name:'--' }}</span>
      </template>
    </el-table-column>
    <el-table-column align="center" prop="lng" label="经度" :formatter="formatter" sortable />
    <el-table-column align="center" prop="lat" label="纬度" :formatter="formatter" sortable />
    <el-table-column align="center" prop="ele" label="高程" :formatter="formatter" sortable />
    <el-table-column align="center" label="操作">
      <template slot-scope="scope">
        <el-button size="mini" @click="handleEdit(scope.row)">编辑</el-button>
        <el-button size="mini" type="danger" @click="handleDelete(scope.row)">删除</el-button>
      </template>
    </el-table-column>
  </el-table>
</template>

<script>
export default {
  props: {
    listObj: {
      type: Object,
      default() {
        return {

        }
      }
    }
  },
  data() {
    return {

    }
  },
  computed: {
    tableData() {
      let result = []
      if (this.listObj.data) {
        result = this.listObj.data.data
      }

      return result
    }
  },
  methods: {
    formatter(row, column) {
      return row[column.property] ? row[column.property] : '--'
    },
    handleEdit(row) {
      this.$emit('handleEdit', row)
    },
    handleDelete(row) {
      this.$emit('handleDelete', row)
    }
  }
}
</script>
<style lang="stylus">

</style>
