import request from '@/utils/request'

export function getAll(params) {
  return request({
    url: '/project',
    method: 'get',
    params
  })
}

export function getOne(id) {
  return request({
    url: '/project/' + id,
    method: 'get'
  })
}

export function addOne(data) {
  return request({
    url: '/project',
    method: 'post',
    data
  })
}

export function updateOne(id, data) {
  return request({
    url: '/project/' + id,
    method: 'put',
    data
  })
}

export function deleteOne(id) {
  return request({
    url: '/project/' + id,
    method: 'delete'
  })
}
