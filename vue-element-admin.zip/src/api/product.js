import request from '@/utils/request'

export function products(params) {
  return request({
    url: '/product',
    method: 'get',
    params
  })
}

export function product(id) {
  return request({
    url: '/product/' + id,
    method: 'get'
  })
}

export function addProduct(data) {
  console.log(data)
  return request({
    url: '/product',
    method: 'post',
    data
  })
}

export function updateProduct(id, data) {
  return request({
    url: '/product/' + id,
    method: 'put',
    data
  })
}

export function deleteProduct(id) {
  return request({
    url: '/product/' + id,
    method: 'delete'
  })
}

export function updateProductActions(id, data) {
  return request({
    url: '/product/' + id + '/actions',
    method: 'put',
    data
  })
}

export function updateProductProperties(id, data) {
  return request({
    url: '/product/' + id + '/properties',
    method: 'put',
    data
  })
}

export function updateProductPolls(id, data) {
  return request({
    url: '/product/' + id + '/polls',
    method: 'put',
    data
  })
}

export function updateProductPortDisplays(id, data) {
  return request({
    url: '/product/' + id + '/portDisplays',
    method: 'put',
    data
  })
}

export function updateProductActionDisplays(id, data) {
  return request({
    url: '/product/' + id + '/actionDisplays',
    method: 'put',
    data
  })
}

export function updateProductSpecs(id, data) {
  return request({
    url: '/product/' + id + '/specs',
    method: 'put',
    data
  })
}
