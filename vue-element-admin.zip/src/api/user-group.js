import request from '@/utils/request'

export function getAll(params) {
  return request({
    url: '/userGroup',
    method: 'get',
    params
  })
}

export function getOne(id) {
  return request({
    url: '/userGroup/' + id,
    method: 'get'
  })
}

export function addOne(data) {
  return request({
    url: '/userGroup',
    method: 'post',
    data
  })
}

export function updateOne(id, data) {
  return request({
    url: '/userGroup/' + id,
    method: 'put',
    data
  })
}

export function deleteOne(id) {
  return request({
    url: '/userGroup/' + id,
    method: 'delete'
  })
}
