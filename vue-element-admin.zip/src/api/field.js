import request from '@/utils/request'

export function getAll(params) {
  return request({
    url: '/field',
    method: 'get',
    params
  })
}

export function getOne(id) {
  return request({
    url: '/field/' + id,
    method: 'get'
  })
}

export function addOne(data) {
  return request({
    url: '/field',
    method: 'post',
    data
  })
}

export function updateOne(id, data) {
  return request({
    url: '/field/' + id,
    method: 'put',
    data
  })
}

export function deleteOne(id) {
  return request({
    url: '/field/' + id,
    method: 'delete'
  })
}
