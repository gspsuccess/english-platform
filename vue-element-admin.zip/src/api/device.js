import request from '@/utils/request'

export function getAll(params) {
  return request({
    url: '/device',
    method: 'get',
    params
  })
}

export function getOne(serialno) {
  return request({
    url: '/device/' + serialno,
    method: 'get'
  })
}

export function getCrcResult(serialno) {
  return request({
    url: '/device/' + serialno + '/crc',
    method: 'get'
  })
}

export function addOne(data) {
  return request({
    url: '/device',
    method: 'post',
    data
  })
}

export function updateOne(serialno, data) {
  return request({
    url: '/device/' + serialno,
    method: 'put',
    data
  })
}

export function deleteOne(serialno) {
  return request({
    url: '/device/' + serialno,
    method: 'delete'
  })
}

export function updateRtu(serialno, data) {
  return request({
    url: '/device/' + serialno + '/rtu',
    method: 'put',
    data
  })
}

export function updateRtuActions(serialno, data) {
  return request({
    url: '/device/' + serialno + '/rtuActions',
    method: 'put',
    data
  })
}

export function updateRtuPorts(serialno, data) {
  return request({
    url: '/device/' + serialno + '/rtuPorts',
    method: 'put',
    data
  })
}

export function updateRtuPolls(serialno, data) {
  return request({
    url: '/device/' + serialno + '/rtuPolls',
    method: 'put',
    data
  })
}

export function updateSetting(serialno, data) {
  return request({
    url: '/device/' + serialno + '/setting',
    method: 'put',
    data
  })
}

export function valid(serialno, data) {
  return request({
    url: '/device/' + serialno + '/valid',
    method: 'post',
    data
  })
}

export function addAll(data) {
  return request({
    url: '/device/all',
    method: 'post',
    data
  })
}

export function updateRtuPortDisplays(serialno, data) {
  return request({
    url: '/device/' + serialno + '/rtuPortDisplays',
    method: 'put',
    data
  })
}

export function updateRtuActionDisplays(serialno, data) {
  return request({
    url: '/device/' + serialno + '/rtuActionDisplays',
    method: 'put',
    data
  })
}

export function updateRtuRegMaps(serialno, data) {
  return request({
    url: '/device/' + serialno + '/rtuRegMaps',
    method: 'put',
    data
  })
}

export function updatePortArrays(serialno, data) {
  return request({
    url: '/device/' + serialno + '/portArrays',
    method: 'put',
    data
  })
}

export function updateCells(serialno, data) {
  return request({
    url: '/device/' + serialno + '/cells',
    method: 'put',
    data
  })
}
