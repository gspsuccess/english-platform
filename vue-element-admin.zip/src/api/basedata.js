import request from '@/utils/request'

export function getProductTypes() {
  return request({
    url: '/base_data/product_type',
    method: 'get'
  })
}

export function getMakers() {
  return request({
    url: '/base_data/maker',
    method: 'get'
  })
}

export function getSoils() {
  return request({
    url: '/base_data/soil',
    method: 'get'
  })
}

export function getRegions() {
  return request({
    url: '/base_data/region',
    method: 'get'
  })
}

export function getProjects() {
  return request({
    url: '/base_data/project',
    method: 'get'
  })
}

export function getFields() {
  return request({
    url: '/base_data/field',
    method: 'get'
  })
}

export function getUserGroups() {
  return request({
    url: '/base_data/user_group',
    method: 'get'
  })
}

export function getProducts() {
  return request({
    url: '/base_data/product',
    method: 'get'
  })
}

export function getDevices() {
  return request({
    url: '/base_data/device',
    method: 'get'
  })
}

export function getProjectsSelect() {
  return request({
    url: '/base_data/projects',
    method: 'get'
  })
}
