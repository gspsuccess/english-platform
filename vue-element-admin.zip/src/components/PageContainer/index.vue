<template>
  <div class="page-wrapper" v-if="total > pageSize">
    <el-pagination
      @current-change="changeCurrentPage"
      :current-page="currentPage"
      :page-size="pageSize"
      layout="prev, pager, next, jumper"
      :total="total">
    </el-pagination>
  </div>

</template>

<script type="text/ecmascript-6">
  export default {
    name: 'PageContainer',
    props:{
      listObj:{
        type:Object,
        default:{}
      }
    },
    computed:{
      total(){
        return this.listObj.data?this.listObj.data.total:0
      },
      currentPage(){
        return this.listObj.data?this.listObj.data.current_page:1
      },
      pageSize(){
        return this.listObj.data?this.listObj.data.per_page:1
      }
    },
    methods:{
      changeCurrentPage(e){
        this.$emit('changeCurrentPage',e)
      }
    }
  }
</script>

<style scoped lang="stylus" rel="stylesheet/stylus">
  .page-wrapper
    padding 12px 0
    border 1px solid #dfe6ec
    border-top none
</style>
